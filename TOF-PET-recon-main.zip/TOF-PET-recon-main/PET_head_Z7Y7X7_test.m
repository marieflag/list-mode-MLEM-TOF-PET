% -*- matlab -*- (enables emacs matlab mode)

%% Input parameters

DATA_FILE = 'Pos_LAT_10ps';%%path of input data file

PRECALCULATED_EV = 0; 

SIMU_FILE = 'ParamHead.bin';%%command not in use




%% Output parameters

RESULTS_DIR = '/home/Data/Outputs/';

%% Data type
DATA_TYPE = 'PET';       % 'PET'


%% Sensitivity 
SENSITIVITY = 'OFF' ;       % 'ON', 'OFF'. Recommended MODEL 'cos0rho0' when sensitivity is 'OFF'
                           % and 'cos1rho2' when the SENSITIVITY is 'ON'
SENSITIVITY_FILE = ' ';
%%   Data selection
SAMPLES =1;                            % for statistical studies
COUNTS_PER_SAMPLE =80000;
%200000;                 % nb of events to treat
PRESELECT=1;                           % COUNTS_PER_SAMPLE is:
                                       % if 0, nb of detected events
                                       % if 1, nb of useful events
if (PRECALCULATED_EV == 0)             % First event to be analysed from the .tra file
  FIRST = 3;                            % Should be >= 1
end
STORE_EV = 1;                          % Store preprocessed =1 or not =0

%%   Reconstructed volume

VOXELS_FILTER  = [9, 9, 9];


VOLUME_DIMENSIONS = [15,0.2,15] ; %in cm for line2cm sivan
VOXELS = [300, 4, 300] ; 
VOLUME_CENTRE = [0, 10, 0];

%   Iterations
DATA_TYPE_MEGA=0;% 0 is default value
FIRST_ITERATION=0;                     % continue iterations;
                                       % 1 means from the beginning
ITERATIONS = 0;
LAST_ITERATION=FIRST_ITERATION+ITERATIONS;
ALGORITHM = 1;          % 0=CV, 1=CV_eu (energy uncertainty, sigma on angle), 
                        

SENSITIVITY_MODEL = 'block';  
MODEL = 'cos1rho0';       % cos1rho0: cos/rho
                       
WIDTH_FACTOR=100;         % thicker cones 
NB_SIGMA = 3;



%%   Energy a priori
ENERGY_FLAG = 0;               % ANY=0
if (ENERGY_FLAG==1)            % total energy in some range
  ENERGY_MIN = 450.5;         % lower bound, keV
  ENERGY_MAX = 551.5;         % upper bound, keV
end
if (ENERGY_FLAG==2)            % known total energy
  ENERGY_TOTAL=511;           % the total energy, keV
end

%%   Camera properties
% Coordinates w.r. to the absolute frame

DET_SIZE=[5.3,5.3,3];
DET_VOXELS = [24,12,6];
% SPATIAL_UNCERTAINTY = 1;         % 1=yes, 0=no
if (ALGORITHM==2)
    ABS_VOXEL_SAMPLING = 4;          % nb points to sample a voxel vertically;
    WEIGHTS = [0, 0, 0, 1];           
end
 


NB_CAMERAS = 1;
% 
NB_MODULES = 8;
NB_SECTORS = 1;
RAD = 6.71;
NB_CAMERAS = 1;
% 
%% Hodoscope a priori
HODOSCOPE_FLAG=0;                           % ON=1, OFF =0;
if (HODOSCOPE_FLAG > 0)
  BEAM_SIGMA = 2 ;                  % Gaussian hodoscope, cm
  BEAM_WIDTH_FACTOR =3 ;            % number of sigma
  BEAM_ENTRY_POINT =[-10, 0, 0];         % a point on the beam line
  BEAM_DIRECTION =[1, 0, 0] ;            % direction of the beam
  shift=0;
  BEAM_FIRST_ITERATION=FIRST_ITERATION+shift;
  BEAM_ITERATIONS=ITERATIONS-shift;
  BEAM_INCLUSION='ONLYHODO';         % CONSTANT, LINEAR, FORCE, FORCEINV, ALTERNATE
end
