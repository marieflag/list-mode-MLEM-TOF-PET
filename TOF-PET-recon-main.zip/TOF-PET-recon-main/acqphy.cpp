
#include <sys/stat.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <string.h>

#include "acqphy.h"


int Event::skip_event(std::ifstream& file, Head & head, data_format & format, int filenumber)
{

  clear();
  int ok=0;

  ok=read_PET(file, filenumber);

  return ok;
}


int Event::read_event_PET(std::ifstream& file, Head & head, data_format & format, int filenumber)
{

  clear();
  int ok=0;

  ok=read_PET(file, filenumber);


  if (ok!=0)
    {
      return ok;
    }
  // calculation of energy-related parameters


  if (ok < 0) return ok;



  return ok ;
}

int Event::read_PET(std::ifstream& file,int filenumber)
{


  std::string line;
  std::string item;

  double x=0;
  double v0,v1,v2,v00,v10,v20;
  double v3,v4,v5;
  double headid1, headid2;
  double pixelid1, pixelid2;


  //float  eventime1, eventime2;
    //int tm;

  int row = 0;

  getline(file,line);
  
  while (!file.eof()&&row<1){
	    row++;
    	std::stringstream ss(line);      // Set up a stream from this line
        ss>>item>>id;
        ss>>item>>item>>item>>item>>item>>Sourceid;

        ss>>item>>v0>>item>>v1>>item>>v00;
      
     
       
//        V1.setPoint(0.1*v0,0.1*v1,0.1*v2);
        ss>>item>>v10>>item>>v20>>item>>eventime1>>item>>Ee>>item>>v0>>item>>v1>>item>>v2;

        V1_source.setPoint(0.1*v00,0.1*v10,0.1*v20);
      
 //       ss>>item>>time>>item>>item>>item>>item>>item>>Ee>>item>>v0>>item>>v1>>item>>v2;
        V1.setPoint(0.1*v0,0.1*v1,0.1*v2);

        ss>>item>>Baseid1>>item>>headid1>>item>>Level2id1>>item>>Level3id1>>item>>pixelid1>>item>>Level5id1>>item>>item>>item>>item>>item>>item>>item>>item>>item;
      
      // std::cout << "Event time1 = "<< Baseid1 <<"level2 = "<< Level2id1<<"level3 = "<< Level3id1<<"level5 = "<< Level5id1<< '\n';
      ss>>item>>item>>item>>item>>v00>>item>>v10>>item>>v20>>item>>eventime2>>item>>item>>item>>v3>>item>>v4>>item>>v5;

        V2_source.setPoint(0.1*v00,0.1*v10,0.1*v20);

        V2.setPoint(0.1*v3,0.1*v4,0.1*v5);

        ss>>item>>Baseid2>>item>>headid2>>item>>Level2id2>>item>>Level3id2>>item>>pixelid2>>item>>Level5id2;// Each item delineated by spaces adds one to cols
        Headid = filenumber;

        CrystalID1 = pixelid1;
        CrystalID2 = pixelid2;
      
        Level4id1 = pixelid1;
        Level4id2 = pixelid2;

        SectorID1 = headid1;
        SectorID2 = headid2;


  }


  return 0;
}




const void Event::display() const  //displays event at standard output
{
  std::cout << "ID "<< id <<'\n';
  std::cout << "V1 " << V1 << '\n';
  std::cout << "V2 " << V2 << '\n';


  std::cout << "Ee " << Ee << '\n';


}


const void Event::save_processed(std::ofstream& file) const
{
  //std::string item;
  file << "Event_ID "<< id <<'\n';
  file<< "Pixel_ID "<<Pixelid<<'\n';
  file<<"Head_ID "<<Headid<<'\n';

  file << "V1 " << V1 << '\n';
  file << "V1_source " << V1_source << '\n';
  file << "V2 " << V2 << '\n';
  file << "V2_source " << V2_source << '\n';


  file << "Ee " << Ee << '\n';

  file << "CrystalID " << CrystalID1 << " " << CrystalID2 << "\n";

  file << "SectorID " << SectorID1 << " "<< SectorID2 << "\n";

  file << "Time " << eventime1 << " "<< eventime2 << "\n\n";


}

bool Event::load_processed(std::ifstream& file)
{
  double tmp;
  std::string line;
  bool ok;
  do 
    {
      file >> line;
      ok = (line != "Event_ID") && !file.eof();
      if (ok)
	{
	  std::cout << "Event::load_processed : not yet the beginning of an event "<< line <<'\n';
	  return false;
	}
    }
  while (ok);
  if (file.eof()) return false;

  file >> id ;
  file >>line>>Pixelid;
  file >> line >> Headid;

  double v0,v1,v2;
  file >>line >> v0 >> v1 >> v2 ;
  V1.setPoint(v0,v1,v2);
  
  file >>line >> v0 >> v1 >> v2 ;
  V1_source.setPoint(v0,v1,v2);

  file  >> line >> v0 >> v1 >> v2  ;
  V2.setPoint(v0,v1,v2);
    
  file >>line >> v0 >> v1 >> v2 ;
  V2_source.setPoint(v0,v1,v2);
    
  file  >> line >> v0 >> v1 >> v2;
  axis.setPoint(v0,v1,v2);

  file >>  line >> Ee;
  file >>  line >> CrystalID1 >> CrystalID2;
  file >>  line >> SectorID1 >> SectorID2;
  file >>  line >> eventime1 >> eventime2;

  getline(file,line);
  return true;
}




bool save_processed_all(char filename[], const std::vector<Event> & ev_RAM)
{
  std::ofstream fp;
  fp.open(filename);
  if (!fp)
    {
      std::cout<<"Error in vect_of_events::save_processed_all: opening of the processed events file " << filename<< " failed\n";
      return false;
    } 
  for (auto &&ev :ev_RAM)
    { 
      ev.save_processed(fp);
    }
  fp.close();
  return true;
}


bool load_processed_all(char filename[], std::vector<Event>& ev_RAM)
{
  std::ifstream fp;
  fp.open(filename);
  if (!fp)
    {
      std::cout<<"Error in load_processed_all: opening of the processed events file " << filename<< " failed\n";
      return false;
    } 
  ev_RAM.clear();
  Event ev;
  bool ok = true;
  while (ok)
    { 
      ok =ev.load_processed(fp);
      if (ok)	
	{
	  //ev.display();
	  ev_RAM.push_back(ev);
	  // std::cout << "load_processed_all\n";
	  // (ev_RAM.back()).display();
	}
      // else
      // ev.display();
    }
  fp.close();
  return true;
}



bool load_processed_nb(char filename[], std::vector<Event>& ev_RAM, unsigned long int nb)
{
  std::ifstream fp;
  fp.open(filename);
  if (!fp)
    {
      std::cout<<"Error in load_processed_all: opening of the processed events file " << filename<< " failed\n";
      return false;
    } 
  ev_RAM.clear();
  Event ev;
  bool ok = true;
  unsigned long int count=0;
  while (ok && count<nb)
    { 
      ok =ev.load_processed(fp);
      if (ok)	
	{
	  //ev.display();
	  ev_RAM.push_back(ev);
	  // std::cout << "load_processed_all\n";
	  // (ev_RAM.back()).display();
	}
      else
	(ev_RAM.back()).display();
      // ev.display();
      count++;
    }
  fp.close();
  return true;
}

bool read_only_ev(std::ifstream& dfp, Head & head, int first, data_format df, int filenumber)
// Read "number" events from the data file, no processing
{
  Event ev; 
  int total_read=1;
  std::string line;

  for (int i=0;i<13; i++)
    getline(dfp,line);// 14 corresponds to the first event in *.txt file transferred from *.root

  while (!dfp.eof() && (total_read<first))
    {
      ev.skip_event(dfp, head, df, filenumber);
      total_read++;
    }

  return dfp.eof();
}




int read_and_analyze_ev_PET(std::ifstream& dfp, std::vector<Event> & ev_RAM, Head & head, unsigned long int cps, bool presel, data_format df, int filenumber)
// Read "cps" events from the data file, analyse and push valid events to ev_RAM
{
  Event ev;
  unsigned long int total_read=0, valid = 0;
  int ok = 0;
  int not_Compton = 0, cos_beta_invalid = 0, not_sca = 0, not_abs = 0;
  int not_in_camera = 0;
    
   std::string line;
    for (int i=0;i<13; i++)
        getline(dfp,line);
    
  while (!dfp.eof() && ((!presel && (total_read<cps))||(presel && (valid<cps))) && ((ok>=0) || (ok==-4)))
    {
      ok=ev.read_event_PET(dfp, head,df, filenumber);
      switch (ok)
	{
	case 0:    // coincidence valid
	  total_read++;
	  valid++;
	  ev_RAM.push_back(ev);
	  break;

	}
    }
  return 0;
}


int ParamReco::readParamInput(int argc, char * argv[], bgeot::md_param & PARAM)
{
  char *extension = strrchr( argv[1], '.');
  char * pwd = strrchr( argv[1], '/');
  run_name = argv[1];
  
  if (extension ==NULL || strncmp(extension, ".m",2)!=0)
    {
      std::cout<<"extension error, expected .m file. \n";
      return -1;
    }
  if (pwd!=NULL)
    {
      run_name.erase(0,pwd-argv[1]+1);
      run_name=run_name.substr(0,extension-pwd-1);
    }
  else
    {
      run_name=run_name.substr(0,extension-argv[1]);
    }
  std::cout<< "\n~~~~~~ * Run name and data *~~~~~~~\n\n";
  std::cout <<"Run name: " <<run_name<< '\n';

  data_file = PARAM.string_value("DATA_FILE","Data file ");
  std::cout << "Data from " << data_file << '\n';

  simu_file = PARAM.string_value("SIMU_FILE", "Simulation geometry file");
  std::cout << "Simulation geometry is described in" <<simu_file<<"\n";
  precalc_EV = PARAM.int_value("PRECALCULATED_EV", "Preprocessed events may be found on the disk or not 1|0") ; 
  if (precalc_EV)
    std::cout << "The file with the analyzed events will be considered instead of the .tra file\n";

  return 0;
}

int ParamReco::readParamOutput(bgeot::md_param & PARAM)
{
 
  std::cout<< "\n~~~~~~ * Results *~~~~~~~\n\n";
  results_path = PARAM.string_value("RESULTS_DIR","directory with the results ");
  std::cout<< "The results will be put in "<<results_path <<'\n';

  struct stat buf;
  int ret;
  ret = stat (results_path.c_str(), &buf);
  if (ret == -1 && errno == ENOENT) 
    {
      ret = mkdir(results_path.c_str(), 0755);
      if (ret == -1) 
	{
	  std::cout<< "Could't create directory "<< results_path << '\n';
	  return -1;
	}
    } 
  events_file = results_path+run_name;
  std::cout<< "Preprocessed events files: "<< events_file << ".sample*.events.txt\n";
  return 0;
}

int ParamReco::readDataType(bgeot::md_param & PARAM)
{
  int err;
  std::string string_content = PARAM.string_value("DATA_TYPE","Data type ");
  if (string_content.compare("Gate") ==0)
    df=Gate;
  return 0;
}


int ParamReco::readParamDataSelection(bgeot::md_param & PARAM)
{
  std::cout<< "\n~~~~~~ * COUNTS *~~~~~~~\n\n";
  nb_samples=PARAM.int_value("SAMPLES", "number of samples from data file ");
  std::cout<< "The events will be binned in " << nb_samples << " samples (for statistical studies)\n";
  cps = PARAM.int_value("COUNTS_PER_SAMPLE", "number of events per sample ");
  presel = (PARAM.int_value("PRESELECT", "event selection ")>0);
  if (presel)
    std::cout<< "Number of USEFUL events per sample (cones intersecting the volume): " << cps<<'\n';
  else 
    std::cout<< "Total number of DETECTED events per sample (not only cones intersecting the volume): " << cps<<'\n';

  if (!precalc_EV)
    first = PARAM.int_value("FIRST", "event to begin with ");
  else 
    first = 1;
  store_EV = PARAM.int_value("STORE_EV", "Preprocessed events will be stored in a file or not 1|0") ;
  std::cout<< "Event to begin with: "<< first << "\n";
  return 0;
}



int  ParamReco::readParamEnergy(bgeot::md_param & PARAM)
{
  std::cout<< "\n~~~~~~ * ENERGY SELECTION *~~~~~~~\n";
  int energy_selection = PARAM.int_value("ENERGY_FLAG", "energy flag ");
  
  switch (energy_selection)
    {
    case 0:
      std::cout<< "Energy selection OFF \n" ;
      flag_energy=ANY;
      break;
    case 1:
      std::cout<< "Energy selection ON: acceptance interval \n" ;
      flag_energy=RANGE;
      Emin = PARAM.real_value("ENERGY_MIN", "minimum allowed total energy"); 
      Emax = PARAM.real_value("ENERGY_MAX", "maximum allowed total energy"); 
      std::cout<< "Minimal allowed total energy: " << Emin <<" keV\n";
      std::cout<< "Maximal allowed total energy: " << Emax <<" keV\n";
      break;
    case 2:
      std::cout<< "Energy selection ON: known total energy \n" ;
      flag_energy=KNOWN;
      Etot = PARAM.real_value("ENERGY_TOTAL", "known initial energy"); 
      std::cout<< "Initial energy of the photons: " << Etot <<" keV \n";
      break;
    default :
      std::cout<< "Unknown energy selection parameter \n" ;
    }
  return 0;
}


int  ParamReco::readParamCamera(bgeot::md_param & PARAM, Head & head)
{
  std::cout<<"\n\n~~~~~* Configuration of the  DC SPECT geometry*~~~~~\n";
  std::vector<bgeot::md_param::param_value> tmp ;


  tmp= PARAM.array_value("DET_SIZE", " dimensions of the detector ");
  head.set_det_dim(tmp[0].real(),tmp[1].real(),tmp[2].real());
  tmp= PARAM.array_value("DET_VOXELS", " nb detector units ");
  head.set_det_vox(int(tmp[0].real()),int(tmp[1].real()),int(tmp[2].real()));
  head.set_det_corner();

  head.set_det_vox_size();
  int nb_cameras = PARAM.int_value("NB_CAMERAS", "Number of heads in the ring ");
  head.set_nb_cameras(nb_cameras);

  int nb_modules = PARAM.int_value("NB_MODULES", "Number of modules in the ring ");
  head.set_nb_modules(nb_modules);

  int nb_sectors = PARAM.int_value("NB_SECTORS", "Number of sectors in the module ");
  head.set_nb_sectors(nb_sectors);
  //char parameter_name[40] ;

  double rad_r = PARAM.int_value("RAD", "System diameter in cm");
  head.set_rad(rad_r);

  std::cout<<"Size of the detector: "<< head.get_det_dim()<< std::endl;


  return 0;
}


int ParamReco::readParamVolume(bgeot::md_param & PARAM)
{
  std::cout<< "\n~~~~~~ * VOLUME *~~~~~~~\n";
  std::vector<bgeot::md_param::param_value> tmp ;
  tmp = PARAM.array_value("VOLUME_DIMENSIONS", "dimensions of the volume");
  Point volume_length(tmp[0].real(),tmp[1].real(),tmp[2].real());
  std::cout << "Volume dimensions: " << volume_length << std::endl;
  tmp= PARAM.array_value("VOXELS", "nb voxels of the volume");
  std::cout << "Voxels in the volume: [ " ;
  for (int i=0; i<3; i++) 
    {
      nb_vox[i]=int(tmp[i].real());
      std::cout<<nb_vox[i] << " ";
    }
  std::cout << "]\n";
  int total_nb_voxels=nb_vox[0]*nb_vox[1]*nb_vox[2]; 
  voxel_length = volume_length/nb_vox ;
  std::cout << "Voxel length: "<< voxel_length<< std::endl;

  tmp= PARAM.array_value("VOLUME_CENTRE", "centre of the volume");
  Point frame_center(tmp[0].real(),tmp[1].real(),tmp[2].real());
  std::cout << "Volume centre: " << frame_center <<std::endl;
  corner = frame_center-volume_length/2.0;
  std::cout << "Corner: " << corner << std::endl;


    tmp= PARAM.array_value("VOXELS_FILTER", "nb voxels of the filter");
     for (int i=0; i<3; i++)
       {
         size_filter[i]=int(tmp[i].real());
        // std::cout<<size_filter[i] << " ";
       }

  return 0;
}


int  ParamMLEM::readParamMLEM(bgeot::md_param & PARAM, Head & head)
{
  std::cout<< "\n~~~~~~ * ITERATIONS *~~~~~~~\n";
  iter_first = PARAM.int_value("FIRST_ITERATION", "first iteration");
  if (iter_first<0) 
    {
      std::cout << "FIRST_ITERATION should not be < 0; automatically set to 0\n";
      iter_first=0;
    }
  std::cout << "First iteration: " << iter_first << "\n";
  iter_nb = PARAM.int_value("ITERATIONS", "number of iterations");
  std::cout << "Number of iterations: " << iter_nb << "\n";


  int alg = PARAM.int_value("ALGORITHM", "algorithm");
  switch (alg) 
    {
    case 0:
      std::cout<< "Algorithm: CV with fixed thickness of cones \n";
      algorithm=CV;
      break;
    case 1:
      std::cout<< "Algorithm: CV with energy uncertainty \n";
      algorithm=CV_eu;
      break;
    default:
      std::cout<< "Algorithm: error\n";
      return 1;
    }

  std::vector<bgeot::md_param::param_value> tmp;



  std::string sa =  PARAM.string_value("MODEL", "model"); 
  bool flag_test=(sa=="cos0rho0")||(sa=="cos1rho0");
  if (!flag_test)  
    { 
      std::cout<< "Unknown model\n";
      return 1;
    };
  if (sa=="cos1rho0")
    {
      std::cout<< "Model: cos1rho0 \n";
      model=cos1rho0;
    };

  width_factor = PARAM.real_value("WIDTH_FACTOR", " thicker cones ");
  nb_sigma = PARAM.real_value("NB_SIGMA", " FWHM ");
  if(nb_sigma==0)
    {
    nb_sigma=3;
    }
  return 0;
}



int ParamMLEM::readParamSensitivity(bgeot::md_param & PARAM)
{
  std::cout<< "\n~~~~~~ * Sensitivity *~~~~~~~\n\n";
  std::string string_content = PARAM.string_value("SENSITIVITY","Sensitivity is ON or OFF ");
  sensitivity_flag = string_content.compare("OFF");
  if (sensitivity_flag)
    std::cout << "Sensitivity is ON"<< std::endl;
  else
    std::cout << "Sensitivity is OFF"<< std::endl;

  std::string sm =  PARAM.string_value("SENSITIVITY_MODEL", "sensitivity model");
  bool flag_test=(sm=="block");
  if (!flag_test)
    {
      std::cout<< "Unknown sensitivity model ; use sca\n";
      sens_model=block;
    };
  if (sm=="block")
    {
      std::cout<< "Sensitivity model: block \n";
      sens_model=block;
    };

  return 0;
}


int  ParamMLEM::readParam(int argc, char * argv[], Head & head)
{
  int err;
  bgeot::md_param PARAM;
  PARAM.read_command_line(argc, argv);
  err = readParamInput(argc, argv, PARAM);
  if (err) return -1;
  err = readParamOutput(PARAM);
  if (err) return -1;
  err = readDataType(PARAM);
  err = readParamSensitivity(PARAM);
  err = readParamDataSelection(PARAM);
  err = readParamVolume(PARAM);
  err = readParamCamera(PARAM, head);  //to be done before readParamMLEM
  err = readParamMLEM(PARAM, head);
  err = readParamEnergy(PARAM);


  std::cout<< "\n~~~~~~ * HODOSCOPE *~~~~~~~\n";
  flag_hodoscope = PARAM.int_value("HODOSCOPE_FLAG", "hodoscope ");
  if (flag_hodoscope == 0)
    std::cout<< "Hodoscope OFF \n" ;
  else
    std::cout<< "Hodoscope ON \n" ;

  return 0;
}
