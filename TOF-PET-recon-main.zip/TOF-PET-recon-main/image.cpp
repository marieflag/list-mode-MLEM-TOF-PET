#include <iostream>
#include <fstream>
#include <math.h>
#include "image.h"



Point::Point(double xx, double yy, double zz) : x(xx), y(yy), z(zz)
{
}

Point::Point(Point const& P) 
{
  x = P.x;
  y = P.y;
  z = P.z;
}


void Point::setPoint(double xx, double yy, double zz)
{
  x = xx;
  y = yy;
  z = zz;
}

void Point::operator=(Point const& P)
{
  x = P.x;
  y = P.y;
  z = P.z;
}

Point& Point::operator+=(const Point& P)
{
  x += P.x;
  y += P.y;
  z += P.z;
  return *this;
}

Point& Point::operator-=(const Point& P)
{
  x -= P.x;
  y -= P.y;
  z -= P.z;
  return *this;
}


Point& Point::operator*=(const int* C)
{
  x *= C[0];
  y *= C[1];
  z *= C[2];
  return *this;
}

Point& Point::operator*=(const double C)
{
  x *= C;
  y *= C;
  z *= C;
  return *this;
}

Point& Point::operator/=(const int* C)
{
  x /= C[0];
  y /= C[1];
  z /= C[2];
  return *this;
}

Point& Point::operator/=(const double C)
{
  x /= C;
  y /= C;
  z /= C;
  return *this;
}

void Point::display(std::ostream& flux) const
{
  flux << x<< ' '<< y << ' '<< z;
}

Point Point::get_local_coord(const Point &O, const Point &Ox, const Point &Oy, const Point &Oz) const
  {
    Point translated((*this)-O);
    Point P_loc(translated*Ox, translated*Oy, translated*Oz);
    return P_loc;
  }

Point Point::get_absolute_coord(const Point &O, const Point &Ox, const Point &Oy, const Point &Oz) const
{
  Point P_abs = O+x*Ox+y*Oy+z*Oz;
  return P_abs;
}

Point Point::get_spherical_coord(const Point &Ox, const Point &Oy, const Point &Oz) const
{
  Point P;
  Point P_loc((*this)*Ox, (*this)*Oy, (*this)*Oz);
  P.x = sqrt(x*x+y*y+z*z);
  P.y = acos(P_loc.z/P.x);
  P.z = atan2(P_loc.y,P_loc.x);
  return P;
}

bool Point::inVolume(const Point& corner, const Point& volume_dim) const
{
  bool x_ok=(x>=corner.x) && (x<=corner.x+volume_dim.x);
  bool y_ok=(y>=corner.y) && (y<=corner.x+volume_dim.y);
  bool z_ok=(z>=corner.z) && (z<=corner.z+volume_dim.z);
  return (x_ok && y_ok && z_ok);
}

bool Point::inDetector(const Point& dim_detector, const Point& center_detector) const
{
  bool x_ok=fabs(x-center_detector.x)<=dim_detector.x/2.0+0.0001;
  bool y_ok=fabs(y-center_detector.y)<=dim_detector.y/2.0+0.0001;
  bool z_ok=fabs(z-center_detector.z)<=dim_detector.z/2.0+0.0001;
  return (x_ok && y_ok && z_ok);
}


std::ostream &operator<<(std::ostream&flux, const Point & P)
{
  P.display(flux);
  return flux;
}

Point operator+(const Point &P1, const Point &P2)
{
  Point copy(P1);
  copy += P2;
  return copy;
}

Point operator-(const Point &P1, const Point &P2)
{
  Point copy(P1);
  copy -= P2;
  return copy;
}

double operator*(const Point& P1, const Point& P2)
{
  return P1.x*P2.x+P1.y*P2.y+P1.z*P2.z;
}

Point operator*(const int* C, const Point & P)
{
  Point copy(P);
  copy *= C;
  return copy;
}

Point operator*(double C, const Point & P)
{
  Point copy(P);
  copy *= C;
  return copy;
}

Point operator/(const Point & P, const int* C)
{
  Point copy(P);
  copy /= C;
  return copy;
}

Point operator/(const Point & P, double C)
{
  Point copy(P);
  copy /= C;
  return copy;
}





Image::Image(const int* image_size, const Point& voxel_size, const Point& corner)
{
  for (int i=0;i<3; i++)
    {
      DimInVoxels[i]=image_size[i];
    }
  VoxelSize = voxel_size;
  Corner = corner;
  DimInCm =  DimInVoxels*VoxelSize;
  NbVoxels=DimInVoxels[0]*DimInVoxels[1]*DimInVoxels[2];
  Value.assign( NbVoxels,0.0);
}


bool Image::index_1Dto3D(int index_voxel, int& i, int& j, int& k) const
{
  if ((index_voxel<0) || (index_voxel>=NbVoxels)) return false;
  k=index_voxel / (DimInVoxels[0]*DimInVoxels[1]);
  j=index_voxel % (DimInVoxels[0]*DimInVoxels[1]);
  i= j % DimInVoxels[0];
  j = j/DimInVoxels[0];
  return true;
}

int Image::index_3Dto1D(int i,int j, int k) const
{
  if ((i<0)||(i>=DimInVoxels[0])||(j<0)||(j>=DimInVoxels[1])||(k<0)||(k>=DimInVoxels[2])) return -1;
  return (i+j*DimInVoxels[0]+k*DimInVoxels[0]*DimInVoxels[1]);
}

bool Image::coord2index_3D(Point const& P, int& i, int& j, int& k) const
{
  bool inside = P.inVolume(Corner, DimInCm);
  i=int(std::min(int(floor((P.x-Corner.x)/VoxelSize.x)), DimInVoxels[0]));
  j=int(std::min(int(floor((P.y-Corner.y)/VoxelSize.y)), DimInVoxels[1]));
  k=int(std::min(int(floor((P.z-Corner.z)/VoxelSize.z)), DimInVoxels[2]));
  // std::cout<< i<< ' ' << j<< ' ' << k << ' ' << '\n';
  return(inside);
}

int Image::coord2index_1D(Point const& P) const
{
  int i,j,k;
  bool inside=Image::coord2index_3D(P,i,j,k);
  if (inside) 
    return Image::index_3Dto1D(i,j,k);
  else
    return -1;
}


void Image::threshold(void)
{
  double thr=maxabs()/1000;
  for (int i=0; i<NbVoxels; i++)
    if (fabs(Value[i])<thr) Value[i]=0;
}


void Image::filter(void)
{
  int i,k,l=0, step;
  Image copy( DimInVoxels, VoxelSize, Corner);
  for(k=0; k<DimInVoxels[1]*DimInVoxels[2]; k++)
    {
      copy.Value[l] = Value[l]/2+Value[l+1]/4;
      l++;
      for ( ; l<(k+1)*DimInVoxels[0]-1 ; l++)
	copy.Value[l] = Value[l-1]/4+Value[l]/2+Value[l+1]/4;
      copy.Value[l] = Value[l-1]/4+Value[l]/2;
      l++;
    }

  step= DimInVoxels[0];
  //Value.assign (copy.Value.begin(),copy.Value.end());
  for (k=0; k<DimInVoxels[2]; k++)
    for(i=0; i<DimInVoxels[0]; i++)
      {
	l=k*DimInVoxels[0]*DimInVoxels[1]+i;
	Value[l] = copy.Value[l]/2+copy.Value[l+step]/4;
	l +=step;
	for ( ; l<k*DimInVoxels[0]*DimInVoxels[1]+DimInVoxels[0]*(DimInVoxels[1]-1)+i ; l=l+step)
	  Value[l] = copy.Value[l-step]/4+copy.Value[l]/2+copy.Value[l+step]/4;
	Value[l] = copy.Value[l-step]/4+copy.Value[l]/2;
      }
  
  step=DimInVoxels[0]*DimInVoxels[1];
  for(i=0; i<DimInVoxels[0]*DimInVoxels[1]; i++)
    {
      l=i;
      copy.Value[l]=Value[l]/2+Value[l+step]/4;
      l +=step;
      for ( ; l<i+(DimInVoxels[2]-1)*DimInVoxels[0]*DimInVoxels[1]; l=l+step)
	copy.Value[l]=Value[l-step]/4+Value[l]/2+Value[l+step]/4;
      copy.Value[l]=Value[l-step]/4+Value[l]/2;
    }
  Value.assign (copy.Value.begin(),copy.Value.end());
}


void Image::multiply(const std::vector<double> mult, const std::vector<double> divisor)
{
  for(int i=0; i<NbVoxels; i++)
    Value[i] *= mult[i]/divisor[i];
}

bool Image::setIntensity(const std::vector<int> index_voxel, const std::vector<double> value)
{
  if (index_voxel.size()!=value.size()) return false;
  for(int i=0; i<index_voxel.size(); i++)
    Value[index_voxel[i]] = value[i];
  return true;
}

double Image::maximum() const
{
  double max = 0.0;
  for (int i = 0; i<NbVoxels;i++)
    if (Value[i] > max) max = Value[i];
  return max;
}


double Image::minimum() const
{
  double min = Value[0];
  for (int i = 1; i<NbVoxels;i++)
    if (Value[i] <= min) min = Value[i];
  return min;
}


double Image::maxabs() const
{
  double max = 0.0;
  for (int i = 0; i<NbVoxels;i++)
    if (fabs(Value[i]) > max) max = fabs(Value[i]);
  return max;
}

int Image::readFile(const char *image_file)
{
  std::ifstream fp;
  fp.open(image_file, std::ios::in|std::ios::binary);
  if (!fp.is_open())
    {
      std::cout<<"Unknown file "<<image_file<< '\n';
      return 1;
    }
  fp.read((char *)(&(Value[0])), NbVoxels*sizeof(double));
  if (!fp) 
    {
      std::cout << "Error in " << image_file << ": only "<< fp.gcount()<< " items could be read.\n" ;
      return 1;
    }
  fp.close();
  return 0;
}

const int Image::writeFile(const char *image_file)
{
  std::ofstream fp;
  fp.open(image_file, std::ios::out|std::ios::binary);
  if (!fp.is_open())
    {
      std::cout<<"Unknown file "<<image_file<< '\n';
      return 1;
    }
  fp.write((char*)(&(Value[0])), NbVoxels*sizeof(double));
  fp.close();
  return 0;
}


bool Image::readFromFile(std::ifstream& fp)
{
  fp.read((char *)(&(Value[0])), NbVoxels*sizeof(double));
  return fp.eof();
}

const void Image::writeToFile(std::ofstream& fp)
{
  fp.write((char*)(&(Value[0])), NbVoxels*sizeof(double));
}





double operator*(const Image& I, const Image & J)
// dot product of two images
{
  double sum = 0;
  if (!(J.DimInVoxels[0]==I.DimInVoxels[0] && J.DimInVoxels[1]==I.DimInVoxels[1] && J.DimInVoxels[2]==I.DimInVoxels[2]))
    {
      std::cout << "Error in operator* for images: to calculate dot product the two vectors should have the same length. Return 0"<< std::endl;
      return 0;
    }
  for (int i = 0; i<I.NbVoxels; i++)
    sum += J.Value[i]*I.Value[i];
  return sum;
}


