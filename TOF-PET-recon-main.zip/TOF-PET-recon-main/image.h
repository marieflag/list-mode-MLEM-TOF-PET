#pragma once

#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <cassert>


class Point
{

 public:

  double x,y,z;

  Point(double xx=0, double yy=0, double zz=0);
  Point(Point const& P);

  void setPoint(double xx, double yy, double zz);

  void display(std::ostream& flux) const;

  void operator=(Point const& P);
  Point& operator+=(const Point& P);
  Point& operator-=(const Point& P);
  Point& operator*=(const int* C);
  Point& operator*=(const double C);
  Point& operator/=(const int* C);
  Point& operator/=(const double C);


  double get_max() {return std::max(x,std::max(y,z)) ;}
  //const double dot_product(const Point &P) { return x*P.x+y*P.y+z*P.z; }
  Point get_local_coord( const Point &O, const Point &Ox, const Point &Oy, const Point &Oz) const;
  Point get_absolute_coord(const Point &O, const Point &Ox, const Point &Oy, const Point &Oz) const;
  Point get_spherical_coord(const Point &Ox, const Point &Oy, const Point &Oz) const;
  double norm2() const  {return sqrt(x*x+y*y+z*z);}

  bool inVolume(const Point& corner, const Point& volume_dim) const;

  bool inDetector(const Point& dim_detector, const Point& center_detector) const ;
};

std::ostream &operator<<( std::ostream& flux, Point const& P);
Point operator+(Point const &P1, Point const &P2);
Point operator-(Point const &P1, Point const &P2);
double operator*(const Point& P1, const Point& P2);  // dot product
Point operator*(const int* C, Point const& P);  // point by point product
Point operator*(double C, Point const& P);  // point by point product
Point operator/(Point const& P, const int* C);  // point by point division
Point operator/(Point const& P, double C);  // point by point division





class Image
{

 public:

  int DimInVoxels[3]; // image dimensions in voxels
  Point DimInCm; // image dimensions in cm
  Point VoxelSize; // voxel dimensions in cm
  Point Corner; // coordinates of the corner bottom left, front
  int NbVoxels;
  std::vector<double> Value;


  //Les constructeurs
  Image() : NbVoxels(0) {}
  Image(const int* image_size, const Point& voxel_size, const Point& corner);

  // Methodes qui retournent des indices 1D ou 3D dans l'image
  bool index_1Dto3D(int index_voxel, int& i, int& j, int& k) const;
  int index_3Dto1D(int i,int j, int k) const;
  bool coord2index_3D(Point const& P, int& i, int& j, int& k) const;
  int coord2index_1D(Point const& P) const;
	
  // Calculs sur l'image
  void initialize(double value)
  {
    Value.assign( NbVoxels, value);
  }

  void threshold(void);
  void filter(void);
  void multiply(const std::vector<double> mult, const std::vector<double> divisor);
  bool setIntensity(const std::vector<int> index_voxel, const std::vector<double> value);//Intensité du voxel d'indice_voxel = value
  double maximum() const;//Retourne la valeur maximale des intensitées
  double maxabs() const;//Retourne la valeur maximale des intensitées absolues
  double minimum() const;
  // lecture/ecriture dans un fichier
  int readFile(const char *image_file);
  const int writeFile(const char *image_file);
  bool readFromFile(std::ifstream&  image_file);  // returns eof
  const void writeToFile(std::ofstream& image_file);
};


double operator*(const Image& I, const Image& J);  //dot product of J by I


