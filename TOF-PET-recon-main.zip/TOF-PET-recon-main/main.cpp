#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

//using namespace std;

#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <vector>
#include <unistd.h>

#include "image.h"
#include "acqphy.h"
#include "mlem.h"


int main(int argc, char *argv[])
{

  if (argc<2)
    {
      std::cout<<"missing argument, needs parameters .m file.\n";
      return -1;
    }

  ParamMLEM list_param;



  Head head;
  int err =  list_param.readParam(argc, argv, head);

  if (err) return -2;

 


  std::cout << "\n\n~~~~~ * Start calculation * ~~~~~\n\n";

  // Sensitivity  ----------------------------------------------

  clock_t t;
  std::cout << "Initialization of the sensitivity ... "<<std::endl;
  t = clock();


  double PI = 3.14;
  int nb_vox[3];
  int size_filter[3];
  int size_zeropad[3];
  list_param.get_nb_vox(nb_vox);
  list_param.get_nb_filter(size_filter);
  list_param.get_nb_zeropad(size_zeropad);

  Point detsize = head.get_det_vox();


  // Prepare simulation geometry --------------------------------------

  std::ifstream sfp;



  // Prepare MLEM ------------------------------------------------------

  int sample_id=0;
  std::vector<Event> ev_RAM;
  char name_processed_file[500];
  char name_results_file[500];
  char name_filtre_file[500];

   
  std::ifstream dfp;
  if (!list_param.get_precalc_EV())
    {
        
        for(int count=0;count<head.get_nb_cameras();count++) {char tmp_file[500];
        sprintf(tmp_file,"%s_%d.txt",list_param.get_data_file().c_str(),count+1);
        dfp.open(tmp_file);

            dfp.close();
    }
    }


  // Initialise MLEM object --------------------------------------------

  MLEM mlem;
  mlem.set_SM_param(list_param.get_algorithm(),list_param.get_model(), list_param.get_width_factor(),list_param.get_nb_sigma()); //,list_param.spatial_uncertainty);
  mlem.set_iterations(list_param.get_iter_nb(),list_param.get_iter_first());
  mlem.set_volume(nb_vox,list_param.get_voxel_length(),list_param.get_corner());
  mlem.set_TV(list_param.get_alpha_TV(), list_param.get_Niter_TV());

  if (list_param.get_flag_energy() == KNOWN)  mlem.set_energy_known(list_param.get_Etot());
  if (list_param.get_flag_energy() == RANGE)  mlem.set_energy_range(list_param.get_Emin(),list_param.get_Emax());

  bool end_of_file = dfp.eof();
  int ok;


  //Read parameters for system matrix calculation


  // Run MLEM for each sample ------------------------------------------
  Image image;


 
    
    
    // Prepare sensitivity---------------------------------------------
    
    Image sens(nb_vox,list_param.get_voxel_length(),list_param.get_corner());

    Point index_temp;
    

        sens.initialize(1);
        std::cout<< "Sensitivity is initialized to 1 "<< std::endl;

    

  while ((sample_id<list_param.get_nb_samples()) && (!end_of_file))
    {
      t = clock();
      if (list_param.get_precalc_EV())
	{
	  std::cout << "Read the processed data file for sample " << sample_id << "  ...\n\n";
	  sprintf(name_processed_file, "%s.sample%d.events.txt",list_param.get_events_file().c_str(),sample_id);
	  load_processed_nb(name_processed_file, ev_RAM, list_param.get_cps());
	  if (list_param.get_store_EV())
	    {
	      sprintf(name_processed_file, "%s.sample%d.eventspre.txt",list_param.get_events_file().c_str(),sample_id);
	      if (save_processed_all(name_processed_file, ev_RAM))
		std::cout << "Processed events file for sample "<< sample_id << " was saved\n\n";
	      else 
		{
		  std::cout << "Processed events file for sample "<< sample_id << " could not be saved\n";
		  return 1;
		}
	    }
	}
      else
	{
        
        for (int count=0; count<head.get_nb_cameras();count++){
        int filenumber=count+1;
	  std::cout << "Read and analyse data file for sample " << sample_id <<" Head "<<filenumber << "  ...\n\n";
    
        char tmp_file[500];
        sprintf(tmp_file,"%s_%d.txt",list_param.get_data_file().c_str(), filenumber);
        dfp.open(tmp_file);
       
            ok = read_and_analyze_ev_PET(dfp, ev_RAM, head, list_param.get_cps(), list_param.get_presel(), list_param.get_df(),filenumber-1);

	  if (ok == -2) return 1;
	  end_of_file = ((ok==-1)||dfp.eof());
      dfp.close();
        }
	  if (list_param.get_store_EV())
	    {
	      sprintf(name_processed_file, "%s.sample%d.events.txt",list_param.get_events_file().c_str(),sample_id);
	      if (save_processed_all(name_processed_file, ev_RAM))
		std::cout << "Processed events file for sample "<< sample_id << " was saved\n\n";
	      else 
		{
		  std::cout << "Processed events file for sample "<< sample_id << " could not be saved\n";
		  return 1;
		}
	    }
        
	}
      std::cout << "Time spent in processing file Toto: " << ((float)(clock()-t))/CLOCKS_PER_SEC<<" seconds \n\n";
      sprintf(name_results_file, "%s.sample%d",list_param.get_events_file().c_str(),sample_id);

      mlem.Detector_Projection(name_results_file, ev_RAM, head);

         if (!mlem.run(name_results_file, ev_RAM, sens, head)) return 1;

      ev_RAM.clear();
      sample_id++;
    }

  if (dfp.is_open()) dfp.close();

  return 0;
}


