
#include <math.h>
#include <stdlib.h>
#include "mlem.h"
#include <algorithm>


#include <omp.h>




#pragma omp declare reduction(vec_double_plus : std::vector<double> : \
                              std::transform(omp_out.begin(), omp_out.end(), omp_in.begin(), omp_out.begin(), std::plus<double>())) \
                    initializer(omp_priv = omp_orig)



bool MLEM::algo_CV(const Event &ev, Head &head, Image &line)
{
  //do not accounts for spatial uncertainties;

	 Point nb_vox_det_size = head.get_det_vox_size();
	 double doi_blurring = nb_vox_det_size.z/0.03; // in ps

  double PI = 3.14;
  Point ref, V0;
  Point eventloc1, eventloc2;


  const Point &V2 = ev.get_V2(); //V2 is coincidence position 2
  const Point &V1 = ev.get_V1();//V1 is coincidence position 1
    
    const Point &V2_source = ev.get_V2_source(); //V2 is coincidence position 2
    const Point &V1_source = ev.get_V1_source();//V1 is coincidence position 1
  
    double time_fwhm = sqrt(2*pow(width_factor,2) +  2*pow(doi_blurring,2))*0.03;// in cm

    
  int id = ev.get_headid() ;

  float tim1 = ev.get_time1();
  float tim2 = ev.get_time2();

  //std::cout << "diff time = "<< tim1- tim2 << '\n';


  Point OjV1, OjV1_init = line.Corner;
  Point index;
  Point Vcenter = line.Corner + line.DimInCm/2.0;
  Point interc;


 

    
  double sq, ddelta, kbl_j;
  bool non_zero=false;

  Coordinate_transfer_event(ev,head,eventloc1,eventloc2);

 
    
  for(int k=0; k<line.DimInVoxels[2]; k++)
    {
 
      OjV1.z = OjV1_init.z+ k*line.VoxelSize.z;
      //
      for(int j=0; j<line.DimInVoxels[1]; j++)
        {

	  OjV1.y = OjV1_init.y +j*line.VoxelSize.y;

	  for(int i=0; i<line.DimInVoxels[0]; i++)
            {
		  OjV1.x= OjV1_init.x+ i*line.VoxelSize.x;

                
 


       double          tmp = (eventloc2.x - OjV1.x)*(eventloc1.x - eventloc2.x) + (eventloc2.y - OjV1.y)*(eventloc1.y - eventloc2.y) + (eventloc2.z - OjV1.z)*(eventloc1.z - eventloc2.z);
                
                
                double cos1 =  tmp/((eventloc2 - OjV1).norm2()*(eventloc1 - eventloc2).norm2());
                
                ddelta = fabs((OjV1 - eventloc2).norm2()*sqrt(abs(1-cos1*cos1)));

                
double factor = exp(-1*pow(ddelta/line.VoxelSize.get_max(),2)/18);
                
                double timediff = ((V2_source - V2).norm2()- (V1_source - V1).norm2())/30000000000;
                
double d1 = ((V1-V2).norm2() -  timediff*30000000000)/2;   //add time information
double d2 = ((V1-V2).norm2() +  timediff*30000000000)/2;
                
                V0.x = 1/((V1-V2).norm2())*(d2*V1.x + d1*V2.x);
                V0.y = 1/((V1-V2).norm2())*(d2*V1.y + d1*V2.y);
                V0.z = 1/((V1-V2).norm2())*(d2*V1.z + d1*V2.z);
                
        

                double l1 = (OjV1 - V0).norm2();
                
                
                double time_factor = exp(-0.5*pow(l1/time_fwhm,2));
                
//                std::cout << "diff time = "<< timediff << '\n';
                
               
		  switch(model)
		{
		case cos1rho0:

                kbl_j = pow(cos1,4);
		  break;
		}




	      //int ind = i+ j*line.DimInVoxels[0] + k*line.DimInVoxels[0]*line.DimInVoxels[1] + (id)*line.DimInVoxels[0]*line.DimInVoxels[1]*line.DimInVoxels[2];

	     
                line.Value[line.index_3Dto1D(i,j,k)] = factor*time_factor;
	      non_zero=true;

                
            }
	}
    }
    
  return non_zero;
}

bool MLEM::line_calc(Event &ev, Head &head, Image &line)
{
  // return true if the line is not full of zeroes
  line.initialize(0);

  return algo_CV( ev, head, line);


}


int MLEM::backproj(Image & lambda, std::vector<Event> &ev_RAM, Head &head)

{
  // Event ev;
  Point index;
  Point ref;
  double PI = 3.14;
  int good_events = 0;
  std::vector<double> & Val = lambda.Value;
  #pragma omp parallel for reduction(+:good_events) reduction(vec_double_plus:Val)
    
  for (auto i=0; i<ev_RAM.size(); i++)
    {
	  auto & ev = ev_RAM[i];
	  int eid = ev.get_headid();
	  Image line(nb_vox,voxel_length,corner);
      if ((flag_energy == RANGE)&& ((ev.get_Ee()<Emin)||(ev.get_Ee()>Emax))) continue;

      if (line_calc(ev, head, line))
	{
	  for (int k=0; k<line.NbVoxels; k++)
	    Val[k] += line.Value[k];


	  good_events++;


	}
      else
	{
	  ev.set_id(-ev.get_id());
	}
    }

  return good_events;
}

int MLEM::one_iter_with_selection(Image & lambda, std::vector<Event> & ev_RAM, Image &sens, Head &head)

{
  Image line(nb_vox,voxel_length, corner);

  Image BackProj(nb_vox,voxel_length, corner);


  double ForwardProj;
  int good_events = 0, k;
  for (auto && ev : ev_RAM)
    {

      if ((flag_energy == RANGE)&& ((ev.get_Ee()<Emin)||(ev.get_Ee()>Emax))) continue;

      if (line_calc(ev,head, line))
	{
	  good_events++;
	  ForwardProj = line* lambda;
	  for (k=0; k<lambda.NbVoxels; k++)
	    BackProj.Value[k] += line.Value[k]/ForwardProj;
	  //std::cout << "count= "<< count<< '\n';
	}
      else
	ev.set_id(-ev.get_id());
    }

    
  for (k=0; k<lambda.NbVoxels; k++)
    lambda.Value[k] *= BackProj.Value[k]/sens.Value[k];

  return good_events;
}



void MLEM::one_iter_without_selection(Image & lambda, std::vector<Event> & ev_RAM, Image &sens, Head &head)
// Iterate with already selected good events
{
    
    Image line(nb_vox,voxel_length, corner);
    Image BackProj(nb_vox,voxel_length, corner);
    Image temp(nb_vox,voxel_length, corner);
    Point index;
    Point ref;
    double PI = 3.14;
    
    
    double ForwardProj;
    int k;
    
    double sum;
    double log_sum=1;
    
    
    
    
    std::vector<double> & Val = BackProj.Value;
    
    // for (auto && ev : ev_RAM)
#pragma omp parallel for reduction(vec_double_plus:Val)
    for (auto i=0; i<ev_RAM.size(); i++)
    {
        //std::cout << "Event id = "<< ev.get_id()<< std::endl;
        Image line(nb_vox,voxel_length, corner);
        double ForwardProj;
        auto & ev = ev_RAM[i];
        int eid = ev.get_headid();
        if (ev.get_id()>0)
        {
            line_calc(ev,head, line);
                 ForwardProj = line*lambda;
            
            
            if ( ForwardProj==0)
            {
                std::cout << "Error: ForwardProj is zero \n";
                continue;
            }
            for (int k=0; k<lambda.NbVoxels; k++)
                Val[k] += line.Value[k]/ForwardProj;
            
            
        
        }
    }
    
   
    for (int k=0; k<lambda.NbVoxels; k++){
        lambda.Value[k] *= BackProj.Value[k]/sens.Value[k];
        
    }
    
    
}





bool MLEM::run( const char *results_file, std::vector<Event> &ev_RAM, Image &sens, Head &head)

{
  Image lambda(nb_vox,voxel_length, corner);
  double alpha_TV_last;
  double log_likelihood;
  double EPSILON= 0.0001;


    Point index;

  char results_file_iter[500];

  // first iteration: -------
  int good_events = -1 ;
  std::cout << "Iteration " << first_iter <<" ...\n\n";

  clock_t t = clock();
  
  if (first_iter == 0){

    good_events = backproj(lambda, ev_RAM, head);// backprojection, selection of valid events

  }

  else
    {
      sprintf(results_file_iter, "%s.iter%d.bin",results_file, first_iter-1);
      if (lambda.readFile(results_file_iter)!=0) return false;
      good_events = one_iter_with_selection(lambda, ev_RAM, sens, head);

    }
  std::cout << "There are " << good_events << " valid events"<< std::endl;
  sprintf(results_file_iter, "%s.iter%d.bin",results_file, first_iter);

  for (int k=0; k<lambda.NbVoxels; k++)
      lambda.Value[k] = lambda.Value[k]/sens.Value[k];///first BackProj/sens;

  if (lambda.writeFile(results_file_iter)) return false;

  t = clock()-t;
  std::cout<< "Time spent in first iteration: "<< ((float)t)/CLOCKS_PER_SEC<<" seconds \n\n";


    lambda.writeFile(results_file_iter);
	  for (int iter = first_iter+1; iter <= first_iter+nb_iter; iter++)
    {

      std::cout << "Iteration " << iter <<" ...\n\n";
      clock_t t = clock();
      
      one_iter_without_selection(lambda, ev_RAM, sens, head);



      sprintf(results_file_iter, "%s.iter%d.bin",results_file, iter);

    	 if (lambda.writeFile(results_file_iter)) return false;
    	            t = clock()-t;
    	            std::cout<< "Time spent in iteration: "<< ((float)t)/CLOCKS_PER_SEC<<" seconds \n\n";

    }


  return true;
}




void MLEM::Detector_Projection( const char *results_file, std::vector<Event> &ev_RAM, Head &head)

{
  Point detsize = head.get_det_vox();

  int det_vox = detsize.x*detsize.y*detsize.z;

  char results_file_proj[500];



  std::vector<double> DetProj(det_vox*head.get_nb_cameras(),0);

	  for (auto i=0; i<ev_RAM.size(); i++){
		  auto & ev = ev_RAM[i];
		  if (ev.get_id()>0){

			  int tmp = ev.get_pixelid();
			  DetProj[tmp + ev.get_headid()*625] +=1;
		  }

	  }


  sprintf(results_file_proj, "%s.Head%d.bin",results_file, head.get_nb_cameras());
  std::ofstream fp;
  fp.open(results_file_proj, std::ios::out|std::ios::binary);
  fp.write((char*)(&DetProj[0]), det_vox*head.get_nb_cameras()*sizeof(double));
  fp.close();




}

void MLEM::Coordinate_transfer_event(const Event &ev, Head &head, Point & eventloc1, Point & eventloc2){


    Point nb_vox_det_size = head.get_det_vox_size();//doi information: layer thickness, calculated as detector thickness/depth of doi

    Point det_size = head.get_det_dim();

    Point det_vox_number = head.get_det_vox();

    //std::cout<< "Time spent in iteration: "<<head.get_det_vox()<<"size"<< det_size<<" seconds \n\n";

    int baseid1 = ev.get_baseid1();
    int level2id1 = ev.get_level2id1();
    int level3id1 = ev.get_level3id1();
    int level4id1 = ev.get_level4id1();
    int level5id1 = ev.get_level5id1();
    
    int baseid2 = ev.get_baseid2();
    int level2id2 = ev.get_level2id2();
    int level3id2 = ev.get_level3id2();
    int level4id2 = ev.get_level4id2();
    int level5id2 = ev.get_level5id2();
    
    
    double bord_top = 12.25;
    double bord_bottom = -16.25;

    if (baseid1>0){
        
        int block1_z = int(level2id1/3);
        int block1_x = level2id1 - block1_z*3;
        int crystal1_z = int(level3id1/det_vox_number.x);
        int crystal1_x = level3id1 - crystal1_z*det_vox_number.x;
        
        eventloc1.x = -1*(nb_vox_det_size.x*crystal1_x + det_size.x*block1_x - det_size.x*3/2);
        eventloc1.z = nb_vox_det_size.x*crystal1_z + det_size.x*block1_z - det_size.x*3/2;
        eventloc1.y = nb_vox_det_size.z*level4id1 + bord_top;
        
        
        int block2_z = int(level2id2/7);
        int block2_x = level2id2 - block2_z*7;
        int crystal2_z = int(level4id2/det_vox_number.y);
        int crystal2_x = level4id2 - crystal2_z*det_vox_number.y;
        
        eventloc2.x = nb_vox_det_size.y*crystal2_x + det_size.y*block2_x - det_size.y*7/2;
        eventloc2.z = nb_vox_det_size.y*crystal2_z + det_size.y*block2_z - det_size.y*7/2;
        eventloc2.y = -1*nb_vox_det_size.z*level5id2 + bord_bottom;
        
        
    }
    
    else{
        
        int block1_z = int(level2id1/7);
        int block1_x = level2id1 - block1_z*7;
        int crystal1_z = int(level4id1/det_vox_number.y);
        int crystal1_x = level4id1 - crystal1_z*det_vox_number.y;
        
        eventloc1.x = nb_vox_det_size.y*crystal1_x + det_size.y*block1_x - det_size.y*7/2;
        eventloc1.z = nb_vox_det_size.y*crystal1_z + det_size.y*block1_z - det_size.y*7/2;
        eventloc1.y = -1*nb_vox_det_size.z*level5id1 + bord_bottom;
        
        
        int block2_z = int(level2id2/3);
        int block2_x = level2id2 - block2_z*3;
        int crystal2_z = int(level3id2/det_vox_number.x);
        int crystal2_x = level3id2 - crystal2_z*det_vox_number.x;
        
        eventloc2.x = -1*(nb_vox_det_size.x*crystal2_x + det_size.x*block2_x - det_size.x*3/2);
        eventloc2.z = nb_vox_det_size.x*crystal2_z + det_size.x*block2_z - det_size.x*3/2;
        eventloc2.y = nb_vox_det_size.z*level4id2 + bord_top;
        
    }
    
    
    
}

