#pragma once

#include <vector>
#include <iostream>
#include <fstream>
#include "image.h"
#include "acqphy.h"
#include "bgeot_ftool.h"
 

class MLEM
{
 private :
  // iterations
  int data_type;
  int nb_iter;
  int first_iter;

  double alpha_TV;
  int Niter_TV;
  // image dimensions
  int nb_vox[3];
  int size_filter[3];
  int size_zeropad[3];
  Point voxel_length;
  Point corner;
  // energy
  Energy_management flag_energy;
  double  Emin;
  double Emax;
  double Etot;

  Algorithm algo;
  Model model;
  Image image;
  double width_factor;
  double nb_sigma;
  bool spatial_uncertainty;

  // bool is_sensitivity_from_file;
  // std::string file_sens;

 public:

 MLEM(): nb_iter(0), flag_energy(ANY) {}


void set_datatype(int datatype)
  {
	 data_type=datatype;
  }

void set_SM_param(Algorithm alg, Model mod, double width, double sigma)//, bool spatial_uncert)
  {
    algo = alg;
    model = mod;
    //spatial_uncertainty = spatial_uncert;
    width_factor = width;
    nb_sigma = sigma;
  }

  void set_iterations(int iter, int first)
  {
    nb_iter = iter;
    first_iter = first;
  }

  void set_volume(int nbvox[], const Point& voxellength, const Point& corn)
  {
    nb_vox[0]=nbvox[0];
    nb_vox[1]=nbvox[1];
    nb_vox[2]=nbvox[2];
    voxel_length = voxellength;
    corner = corn;
  }


  void set_filter(int nbvox[])
  {
    size_filter[0]=nbvox[0];
    size_filter[1]=nbvox[1];
    size_filter[2]=nbvox[2];

  }

  void set_zeropad(int nbvox[])
  {
    size_zeropad[0]=nbvox[0];
    size_zeropad[1]=nbvox[1];
    size_zeropad[2]=nbvox[2];

  }


  void set_energy_range(double  emin, double emax)
  {
    flag_energy=RANGE;
    Emin=emin;
    Emax=emax;
  }

  void set_energy_known(double etot)
  {
    flag_energy=KNOWN;
    Etot=etot;
  }


  void set_TV(double  alpha, int Niter)
  {
    Niter_TV=Niter;
    alpha_TV=alpha;
  }

  bool algo_CV(const Event &ev, Head &head, Image &line);

  bool line_calc(Event &ev, Head &head, Image &line);

  int backproj(Image & lambda, std::vector<Event> &ev_RAM, Head &head);
  int one_iter_with_selection(Image & , std::vector<Event> & ,  Image &, Head &);
  void one_iter_without_selection(Image &, std::vector<Event> &,  Image &, Head &);

  bool run(const char *results_file, std::vector<Event> &ev_RAM, Image &sens, Head &head);
  void Detector_Projection( const char *results_file, std::vector<Event> &ev_RAM, Head &head);
  void Coordinate_transfer_event(const Event &ev, Head &head, Point &, Point &);

};
